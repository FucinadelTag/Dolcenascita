<template lang="html">
    <section class="callToAction">
        <div class="uk-section uk-padding uk-text-center">
            <h3 class="uk-h1 uk-text-bold">Contatta una <span class="text-rosso">Doula</span> Adesso</h3>
            <a href="tel:80080008000" class="uk-button uk-button-primary  uk-button-large">
                <span class="uk-h2 uk-dark"><span uk-icon="icon: receiver; ratio: 2"></span> 800 800 800</span>
            </a>
            <p><i>Numero Gratuito attivo dalle 9 alle 18 da Lunedì a Venerdì</i></p>
        </div>
    </section>


</template>

<script>
export default {
}
</script>

<style lang="scss">
</style>
